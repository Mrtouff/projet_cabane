# Projet Cabane

Fichiers pour le projet de lit cabane.
- `.skp` : fichier SketchUp
- `.dae` : format alternatif
- `.zip` : archive complète